# Hypercluster
A package for clustering optimization with sklearn. 

Install: 
```
pip install hypercluster
```

Docs: https://hypercluster.readthedocs.io/en/latest/

