# Autocluster
A package for clustering optimization with sklearn. 

Install: 
```
pip install autocluster-sklearn
```

Docs: https://autocluster.readthedocs.io/en/latest/

