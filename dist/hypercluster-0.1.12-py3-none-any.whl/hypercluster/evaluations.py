#TODO add label count evals here

#TODO fn that grabs best params from col/yml in smk output, and feeds into clusterer.
